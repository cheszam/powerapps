This contains the PowerApps solution built in the Youtube video https://youtu.be/usTGrplF48I
It also contains all major code used in the video as well as excel data that can be imported. It doesnt contain data for the Team Members relationship

If you dont have dataverse you can simply import the canvas app package "Vid xxx Canvas App Only.zip" on the "Apps" screen. 
If you have dataverse as well as solution import privileges you can go to the "Solutions" screen to import the "Full Solution_......" solution to get the full app or import the "LearnersPackage_...." solution to get the base temmplate to follow along with the tutorial.

Have fun exploring!!!