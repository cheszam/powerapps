This contains the PowerApps solution built in the Youtube video https://youtu.be/QntVPZtwH8E

If you dont have dataverse you can simply import the canvas app package "Vid xxx Canvas App Only.zip" on the "Apps" screen. If you have dataverse as well solution import privileges you can import the "Full Solution_......" on the "Solutions" screen.

Have fun exploring!!!