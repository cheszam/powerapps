This contains the PowerApps solution built in the Youtube video https://youtu.be/jJrtIV6nuRA

If you dont have dataverse you can simply import the canvas app package "Vid xxx Canvas App Only.zip" on the "Apps" screen. 
If you have dataverse as well as solution import privileges you can go to the "Solutions" screen to import the "Full Solution_......" solution to get the full app or import the "LearnersPackage_...." solution to get the base template to follow along with the tutorial.

This will also contain any dataset used in the video in Excel format. This can be imported into your dataverse tables using the "Import Data from Excel" functionality on th table's overview page.

Have fun exploring!!!
